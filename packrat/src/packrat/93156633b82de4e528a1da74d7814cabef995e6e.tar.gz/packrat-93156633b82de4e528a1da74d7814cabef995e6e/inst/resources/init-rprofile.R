#### -- Packrat Autoloader (version 0.2.0.124) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
